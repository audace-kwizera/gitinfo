# Installation des plugins pour connecter sublime text 3 avec GitHub

## Package Control

+ Si ce n'est déjà fait installez [Package Control](https://packagecontrol.io/installation) pour sublime text.

## Les plugins

+ Installez le plugin **Emmet**
`MENU : Preferences>Package Control` ou `Ctrl+Shift+P` Ouvre la console Package Control > choississez `Install Package`
puis recherchez et installez le plugin `Emmet for Sublime Text`
(plus d'infos ici https://packagecontrol.io/packages/Emmet)

+ Installez le plugin **Git**
`MENU : Preferences>Package Control` ou `Ctrl+Shift+P` Ouvre la console Package Control > choississez `Install Package`
puis recherchez et installez le plugin `Git`
(plus d'infos ici https://packagecontrol.io/packages/Git)

+ Installez le plugin **Sublime GitHub**
`MENU : Preferences>Package Control` ou `Ctrl+Shift+P` Ouvre la console Package Control > choississez `Install Package`
puis recherchez et installez le plugin `Sublime GitHub`
(plus d'infos ici https://packagecontrol.io/packages/sublime-github)

## Récuperez le github token pour pouvoir vous connecter à votre compte GitHub

+ Sur GitHub, allez dans profil>settings>developper settings>personal acces tokens puis choississez `generate new token`
(https://github.com/settings/tokens/new)
> Mettez la description de votre choix pour le nom du token.
> Cochez les cases repo,  admin:repo_hook , delete_repo ou toutes les cases en fonction des droits que vous voulez attribuez.
> Copiez le token généré.

## Configuration de sublime text 3

+  Menu : Preferences>Package settings>GitHub>Settings User

Collez votre id token comme ceci et enregistrez

    {
        "github_token": "6423ba8429a152ff4a7279d1e8f4674029d3ef87"
    }

pour créer des comptes supplémentaires cf. Adding Additional Accounts dans (https://packagecontrol.io/packages/sublime-github)


+ création des raccourcis clavier, Menu : Preferences>Package settings>Emmet>Key Bindings User

        [
    		{ "keys": ["ctrl+shift+g", "ctrl+shift+n"], "command": "public_gist_from_selection" },
    		{ "keys": ["ctrl+shift+g", "ctrl+shift+p","shift+n"], "command": "private_gist_from_selection" },
    		{ "keys": ["ctrl+shift+g", "ctrl+shift+o"], "command": "open_gist_in_editor" },
    		{ "keys": ["ctrl+shift+g", "ctrl+shift+c"], "command": "open_gist_url" },
    		{ "keys": ["ctrl+shift+g", "ctrl+shift+u"], "command": "update_gist" }
    	]     

..il ne vous reste plus qu'à utiliser les plugins en passant par les raccourcis clavier ou via la console package control avec le mot clef github